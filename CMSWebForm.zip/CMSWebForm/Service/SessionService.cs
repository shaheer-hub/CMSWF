﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CMSWebForm.Service
{
    public class SessionService
    {
    }
}