﻿using BusinessLayer.Repo;
using DAL.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CMSWebForm.Admin
{
    public partial class AddProduct : System.Web.UI.Page
    {
        clsProduct _product = new clsProduct();
        clsCategory _category = new clsCategory();
        protected void Page_Load(object sender, EventArgs e)
        {
            BindCategories();
            BindProductTypes();
            FillGridView();
        }
        public void FillGridView()
        {
            
            this.GVProducts.DataSource = _product.GetProducts();
            this.GVProducts.DataBind();
        }
        public void BindCategories()
        {
            
            try
            {
                List<Category> catlist = _category.GetCategories();
                this.ddlCategory.DataSource = catlist;
                this.ddlCategory.DataValueField = "CatId";
                this.ddlCategory.DataTextField = "CatName";
                this.ddlCategory.DataBind();
            }
            catch(Exception ex)
            {
                throw ex;
            }
            
        }
        public void BindProductTypes()
        {
            try
            {
                clsProductType _prodType = new clsProductType();
                List<ProductType> prodTypeList = _prodType.GetAllProdTypes();
                this.ddlProdType.DataSource = prodTypeList;
                this.ddlProdType.DataValueField = "Id";
                this.ddlProdType.DataTextField = "ProductTypeName";
                this.ddlProdType.DataBind();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                Product product = new Product();
                product.ProdName = txtName.Text.ToString();
                product.ProdPrice = Convert.ToDecimal(txtPrice.Text);
                product.ProdDescription = txtPDescription.Text.ToString();
                product.CategoryId = Convert.ToInt32(ddlCategory.SelectedValue);
                product.ProductTypeId = Convert.ToInt32(ddlProdType.SelectedValue);
                if (imgUploader.HasFile)
                {
                    int length = imgUploader.PostedFile.ContentLength;
                    byte[] imgbyte = new byte[length];
                    HttpPostedFile img = imgUploader.PostedFile;
                    //set the binary data  
                    img.InputStream.Read(imgbyte, 0, length);
                    string filename = Path.GetFileName(imgUploader.PostedFile.FileName);
                    
                    //be.Eimage=txtimage.  
                    product.PhotoName = filename;
                    product.Photo = imgbyte;
                    
                   
                    
                 }
                clsProduct _product = new clsProduct();
                _product.AddProduct(product);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}